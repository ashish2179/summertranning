Problem 10.2 & 10.3 remain
